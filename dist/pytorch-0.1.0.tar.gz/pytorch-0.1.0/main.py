def main() -> None:
    from ci.checks import run_lint

    run_lint()


if __name__ == "__main__":
    main()
