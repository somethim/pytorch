def some_function():
    return "Hello"
